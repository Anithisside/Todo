package assignment2;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.TitledBorder;

import se.his.it401g.todo.Task;
import se.his.it401g.todo.TaskInputListener;
import se.his.it401g.todo.TaskListener;

public class Custom extends JPanel implements Task {

	private JTextField text;
	private JLabel textLabel;
	private JCheckBox completed = new JCheckBox();
	private JPanel parentPanel;
	private TaskListener listener;

	public Custom() {
		super(new BorderLayout());

		// Initializes components
		this.text = new JTextField("New task", 20);
		this.textLabel = new JLabel();
		this.textLabel.setVisible(false);
		this.parentPanel = this;

		// Adds the text field and label to the center panel
		JPanel center = new JPanel();
		center.add(text);
		center.add(textLabel);
		add(center);

		// Adding listeners for user
		TaskInputListener inputListener = new TaskInputListener(this, text, textLabel);
		this.text.addKeyListener(inputListener);
		this.textLabel.addMouseListener(inputListener);

		// Creates panel for buttons
		JPanel panel = new JPanel();
		panel.setOpaque(true);
		panel.setLayout(new FlowLayout());

		// Adding the red button
		JButton redButton = new JButton("Red");
		panel.add(redButton);
		redButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				toggleColors(Color.RED); // Changes colors to red
			}
		});

		// Adding green button
		JButton greenButton = new JButton("Green");
		panel.add(greenButton);
		greenButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				toggleColors(Color.GREEN); // Changes colors to green
			}
		});

		// Adding remove button
		JButton remove = new JButton("Remove");
		panel.add(remove, BorderLayout.WEST);
		remove.addActionListener(inputListener);

		// Adding button panel to the right side
		add(panel, BorderLayout.EAST);

		// Adding completion checkbox to the left side
		add(completed, BorderLayout.WEST);
		completed.addItemListener(inputListener);

		// Set maximum size and border
		setMaximumSize(new Dimension(1000, 50));
		setBorder(new TitledBorder(getTaskType()));
	}

	// Method to toggle colors(else the task texts are not clearly visible while
	// adding up the colors)
	private void toggleColors(Color color) {
		if (parentPanel.getBackground().equals(color))// Checks if the background color of the parentPanel is equal to
														// the given color
		{
			parentPanel.setBackground(null);// If the background color matches the given color, set the background color
											// of the parentPanel to null
			textLabel.setForeground(Color.BLACK); // Changes text color to black when removing color
		} else {
			parentPanel.setBackground(color);
			textLabel.setForeground(Color.BLACK); // Changes text color to black when setting color
		}
	}

	// Getting the text from text field
	@Override
	public String getText() {
		return text.getText();
	}

	// Getting the task type
	@Override
	public String getTaskType() {
		return "Custom";
	}

	// Setting up the task listener
	@Override
	public void setTaskListener(TaskListener t) {
		listener = t;
	}

	// Getting task listener
	@Override
	public TaskListener getTaskListener() {
		return listener;
	}

	// Checking if task is complete
	@Override
	public boolean isComplete() {
		return completed.isSelected();
	}

	// Getting GUI component
	@Override
	public Component getGuiComponent() {
		return this;
	}
}