package assignment2;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.SwingUtilities;

import se.his.it401g.todo.HomeTask;
import se.his.it401g.todo.StudyTask;
import se.his.it401g.todo.Task;

public class GUI {

	// Panels that make up the sections of the GUI
	private JPanel taskPanel = new JPanel();
	private JPanel topButtonPanel = new JPanel();
	private JPanel buttonPanel = new JPanel();
	private JPanel bottomPanel = new JPanel();
	private JPanel sortPanel = new JPanel();
	// Labels for display and sorting instructions
	private JLabel label = new JLabel("Empty Tasks");
	private JLabel sortLabel = new JLabel("Sort");

	// Scroll pane for task panel to enable scrolling through tasks
	private JScrollPane scroller = new JScrollPane(taskPanel, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
			JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);

	private String[] sorts = new String[] { "Alphabetical order", "Incomplete", "Types" };
	private JComboBox<String> sortTasks = new JComboBox<>(sorts);

	private ArrayList<Task> tasks = new ArrayList<>();

	// Buttons for creating new tasks
	private JButton buttonOne = new JButton("New HomeTask");
	private JButton buttonTwo = new JButton("New StudyTask");
	private JButton buttonThree = new JButton("New CustomTask");

	public GUI() {
		// Action listener for task buttons
		TaskActionListener taskActionListener = new TaskActionListener();
		buttonOne.addActionListener(taskActionListener);
		buttonTwo.addActionListener(taskActionListener);
		buttonThree.addActionListener(taskActionListener);

		bottomPanel.add(label);
		buttonPanel.add(buttonOne);
		buttonPanel.add(buttonTwo);
		buttonPanel.add(buttonThree);
		// Setting the layout managers for task and button panels
		taskPanel.setLayout(new BoxLayout(taskPanel, BoxLayout.PAGE_AXIS));
		topButtonPanel.setLayout(new BorderLayout());
		topButtonPanel.add(buttonPanel, BorderLayout.CENTER);
		topButtonPanel.add(sortPanel, BorderLayout.EAST);
		// Adding components to the sort panel
		sortPanel.add(sortLabel);
		sortPanel.add(sortTasks);

		// Listener for the sorting combobox
		sortTasks.addItemListener(new ItemListener() {
			@Override
			public void itemStateChanged(ItemEvent e) {
				// When a new sort option is selected, the task list is sorted
				if (e.getStateChange() == ItemEvent.SELECTED) {
					sortState();
				}
			}
		});
	}

	private class TaskActionListener implements ActionListener {
		@Override
		public void actionPerformed(ActionEvent e) {
			// Responds to button clicks and creates corresponding task(Home, Study and
			// Custom task)
			Object source = e.getSource();
			Task task = null;

			if (source == buttonOne) {
				task = new HomeTask();
				System.out.println("home task");
			} else if (source == buttonTwo) {
				task = new StudyTask();
				System.out.println("study task");
			} else if (source == buttonThree) {
				task = new Custom();
				System.out.println("custom task");
			}

			if (task != null) {
				// Add the new task to the panel and the task list
				taskPanel.add(task.getGuiComponent());
				tasks.add(task);
				updateLabel1();
				// Refresh the task panel UI to display the new task
				SwingUtilities.updateComponentTreeUI(taskPanel);
			}
		}
	}

	private void updateLabel1() {
		// Updates the bottom label to display the current number of tasks
		label.setText(tasks.size() + " Tasks");
	}

	public void sortState() {
		// Gets the selected sort option and sorts the tasks accordingly.
		String sortMethod = (String) sortTasks.getSelectedItem();
		switch (sortMethod) {
		case "Alphabetical order":
			Collections.sort(tasks, new Comparator<Task>() {
				@Override
				public int compare(Task t1, Task t2) {
					return t1.getText().compareToIgnoreCase(t2.getText());
				}
			});
			break;
		case "Incomplete":
			Collections.sort(tasks, new Comparator<Task>() {
				@Override
				public int compare(Task t1, Task t2) {
					return Boolean.compare(t1.isComplete(), t2.isComplete());
				}
			});
			break;
		case "Types":
			Collections.sort(tasks, new Comparator<Task>() {
				@Override
				public int compare(Task t1, Task t2) {
					if (t1 instanceof StudyTask && !(t2 instanceof StudyTask)) {
						return -1;
					} else if (!(t1 instanceof StudyTask) && t2 instanceof StudyTask) {
						return 1;
					} else if (t1 instanceof HomeTask && !(t2 instanceof HomeTask)) {
						return -1;
					} else if (!(t1 instanceof HomeTask) && t2 instanceof HomeTask) {
						return 1;
					} else if (t1 instanceof Custom && !(t2 instanceof Custom)) {
						return -1;
					} else if (!(t1 instanceof Custom) && t2 instanceof Custom) {
						return 1;
					} else {
						return 0;
					}
				}
			});
			break;
		}

		taskPanel.removeAll();
		// Iterates over each task and adds it to the task panel
		for (Task task : tasks) {
			taskPanel.add(task.getGuiComponent());
		}
		// Refreshes the task panel to reflect the updated list of tasks
		SwingUtilities.updateComponentTreeUI(taskPanel);
	}

	public JScrollPane getScroller() {
		return scroller;
	}

	public JPanel getTopButtonPanel() {
		return topButtonPanel;
	}

	public JPanel getButtonPanel() {
		return buttonPanel;
	}

	public JPanel getBottomPanel() {
		return bottomPanel;
	}

	public JPanel getSortPanel() {
		return sortPanel;
	}

	public JLabel getLabel() {
		return label;
	}

	public JComboBox<String> getSortTasksComboBox() {
		return sortTasks;
	}

	public ArrayList<Task> getTasks() {
		return tasks;
	}

	// Removes a specified task from both the task panel and the tasks list

	public void removeTask(Task task) {
		if (task != null) {
			tasks.remove(task); // Remove the task from the list
			taskPanel.remove(task.getGuiComponent()); // Remove the task's GUI component from the panel
			updateLabel1(); // Update the label to reflect the new number of tasks
			SwingUtilities.updateComponentTreeUI(taskPanel); // Refresh the UI to reflect changes
		}
	}

	// Updates the label with the current number of tasks, showing how many are
	// completed.

	private void updateLabel() {
		long completedCount = 0;
		for (Task task : tasks) {
			if (task.isComplete()) {
				completedCount++;
			}
		}
		label.setText(completedCount + " out of " + tasks.size() + " Completed");
	}

}
