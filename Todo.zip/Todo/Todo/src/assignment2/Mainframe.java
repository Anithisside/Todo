package assignment2;

import java.awt.BorderLayout;

import javax.swing.JFrame;

public class Mainframe extends JFrame {

	private GUI frame = new GUI();

	// It sets up the main window frame with a specific size, layout, and title.
	// This class constructor sets the size and position of the frame.
	public Mainframe() {

		this.setBounds(200, 200, 1000, 600); // Set the bounds for the Mainframe.
		this.setVisible(true);// Make the frame visible to the user.
		this.setLayout(new BorderLayout());// Set the layout manager for the Mainframe.
		this.setTitle("ToDo"); // Set the layout manager for the Mainframe.

		// Adding scroll pane, and bottom and Top button Panel from the GUI class to
		// different positions at the Mainframe.
		this.add(frame.getScroller(), BorderLayout.CENTER);
		this.add(frame.getBottomPanel(), BorderLayout.SOUTH);
		this.add(frame.getTopButtonPanel(), BorderLayout.NORTH);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

}