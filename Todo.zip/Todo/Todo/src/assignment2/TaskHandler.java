package assignment2;

import javax.swing.SwingUtilities;

import se.his.it401g.todo.Task;
import se.his.it401g.todo.TaskListener;

public class TaskHandler implements TaskListener {
	private GUI gui;
	// Static variables to keep track of the total number of tasks created and
	// completed
	private static int createdTaskCount = 0;
	private static int finishedTaskCount = 0;

	public TaskHandler(GUI gui) {
		this.gui = gui;
	}

	// Methods called
	@Override
	public void taskChanged(Task task) {

	}

	@Override
	public void taskCompleted(Task task) {
		finishedTaskCount++;
		gui.getLabel().setText(finishedTaskCount + " out of " + String.valueOf(createdTaskCount) + " Completed");
		// Updates
		SwingUtilities.updateComponentTreeUI(gui.getButtonPanel());
	}

	@Override
	public void taskUncompleted(Task task) {
		finishedTaskCount--;
		gui.getLabel().setText(finishedTaskCount + " out of " + createdTaskCount + " Completed");
		// updates
		SwingUtilities.updateComponentTreeUI(gui.getButtonPanel());
	}

	@Override
	public void taskCreated(Task task) {
	}

	@Override
	public void taskRemoved(Task task) {
		if (task.isComplete() == true) { // Checks if the task was completed and decrement the finishedTaskCount
											// accordingly.

			finishedTaskCount--;
		}
		createdTaskCount--;

		gui.removeTask(task); // Update the GUI to remove the task from the display.
		gui.getLabel().setText(finishedTaskCount + " out of " + String.valueOf(createdTaskCount) + " Completed");
		// Update the GUI label to reflect the new count of finished tasks out of the
		// total created tasks.

	}

	// Setter methods used
	public void setCreatedTask(int value) {
		createdTaskCount += value;

	}

	public void setFinishedTask(int value) {
		finishedTaskCount += value;
	}

	public int getCreatedTask() {
		return createdTaskCount;
	}

	public int getFinishedTask() {
		return finishedTaskCount;
	}

}