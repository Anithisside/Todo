package assignment2;

public class ToDo {

	public static void main(String[] args) {

		Mainframe frame = new Mainframe();// Creating a new instance of the Mainframe class.

	}

}
