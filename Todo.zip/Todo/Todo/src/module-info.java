/**
 * 
 */
/**
 * @author ANIRBAN
 *
 */
module assignment2 {
	requires java.base;
	requires java.se;
	requires it401g.todo;
	exports assignment2;	
}